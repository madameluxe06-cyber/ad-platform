export default function Dashboard(){ return (<div className="container py-20"><h2 className="text-2xl font-bold">Dashboard</h2><p className="mt-4">You are logged in.</p></div>) }

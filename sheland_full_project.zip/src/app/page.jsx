import Link from 'next/link'
export default function Page(){
  return (<main className="container py-14">
    <h1 className="text-4xl font-bold mb-6">Sheland Classifieds</h1>
    <p className="mb-6">Demo platform with Email + Phone OTP authentication (NextAuth + Twilio)</p>
    <div className="space-x-3">
      <Link href="/login" className="px-4 py-2 bg-yellow-400 text-black rounded">Login</Link>
      <Link href="/dashboard" className="px-4 py-2 border rounded">Dashboard</Link>
    </div>
  </main>)
}

import './globals.css'
export const metadata = { title: 'Sheland Classifieds', description: 'Buy & Sell Pakistan' }
export default function RootLayout({ children }) {
  return (<html lang="en"><body>{children}</body></html>)
}

'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'

export default function LoginPage(){
  const [email,setEmail]=useState('')
  const [phone,setPhone]=useState('')
  const router = useRouter()

  async function loginEmail(e){
    e.preventDefault()
    await signIn('email',{ email, redirect:false })
    alert('Check your email for sign-in link')
  }

  async function sendOtp(e){
    e.preventDefault()
    await fetch('/api/send-otp',{ method:'POST', body: JSON.stringify({ phone }), headers:{'content-type':'application/json'} })
    router.push(`/verify-otp?phone=${encodeURIComponent(phone)}`)
  }

  return (<div className="container py-20 max-w-md">
    <h2 className="text-2xl font-bold mb-4">Login</h2>
    <form onSubmit={loginEmail} className="mb-6 space-y-3 border p-4 rounded">
      <input className="w-full p-2 bg-black border rounded" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <button className="w-full bg-yellow-400 text-black p-2 rounded">Login with Email</button>
    </form>
    <form onSubmit={sendOtp} className="space-y-3 border p-4 rounded">
      <input className="w-full p-2 bg-black border rounded" placeholder="Phone (+92...)" value={phone} onChange={e=>setPhone(e.target.value)} />
      <button className="w-full bg-yellow-400 text-black p-2 rounded">Send OTP</button>
    </form>
  </div>)
}

'use client'
import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'

export default function VerifyOtp(){
  const params = useSearchParams()
  const phone = params.get('phone')
  const [otp,setOtp]=useState('')
  const router = useRouter()

  async function submit(e){
    e.preventDefault()
    const res = await fetch('/api/verify-otp',{ method:'POST', body: JSON.stringify({ phone, otp }), headers:{'content-type':'application/json'} })
    const data = await res.json()
    if(data.token){ localStorage.setItem('token', data.token); router.push('/dashboard') } else { alert('Invalid OTP') }
  }

  return (<div className="container py-20 max-w-md">
    <h2 className="text-2xl font-bold mb-4">Verify OTP</h2>
    <form onSubmit={submit} className="space-y-3 border p-4 rounded">
      <input className="w-full p-2 bg-black border rounded" placeholder="OTP" value={otp} onChange={e=>setOtp(e.target.value)} />
      <button className="w-full bg-yellow-400 text-black p-2 rounded">Verify</button>
    </form>
  </div>)
}

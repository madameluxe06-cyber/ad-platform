import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import jwt from 'jsonwebtoken'

export async function POST(req){
  const { phone, otp } = await req.json()
  const user = await prisma.user.findUnique({ where:{ phone } })
  if(!user) return NextResponse.json({ error:'not_found' },{ status:404 })
  if(user.otp !== otp || user.otpExpiry < new Date()) return NextResponse.json({ error:'invalid' },{ status:400 })
  const token = jwt.sign({ id:user.id }, process.env.JWT_SECRET, { expiresIn:'7d' })
  return NextResponse.json({ token })
}

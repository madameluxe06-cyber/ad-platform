import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import twilio from 'twilio'

export async function POST(req){
  const { phone } = await req.json()
  if(!phone) return NextResponse.json({ error:'missing' },{ status:400 })
  const otp = Math.floor(100000+Math.random()*900000).toString()
  await prisma.user.upsert({
    where:{ phone },
    update:{ otp, otpExpiry: new Date(Date.now()+5*60*1000) },
    create:{ phone, otp, otpExpiry: new Date(Date.now()+5*60*1000) }
  })
  const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN)
  await client.messages.create({ to: phone, from: process.env.TWILIO_PHONE, body: `Your OTP is ${otp}` })
  return NextResponse.json({ ok:true })
}

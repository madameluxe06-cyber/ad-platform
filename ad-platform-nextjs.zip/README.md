# ad-platform

Next.js + Tailwind starter for Sheland Classifieds (Ad Platform). Replace or extend files as needed.

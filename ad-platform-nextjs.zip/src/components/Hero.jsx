export default function Hero() {
  return (
    <section id="home" className="max-w-6xl mx-auto px-5 py-20 grid md:grid-cols-2 gap-10 items-center">
      <div>
        <p className="text-gray-400 font-semibold mb-3">Trusted • Local • Premium</p>
        <h2 className="text-3xl font-bold mb-3">
          We help businesses grow with beautiful design & measurable marketing.
        </h2>
        <p className="text-gray-400 mb-6">
          1 provides expert consulting, modern web design, digital marketing and
          brand strategy for businesses that want to stand out.
        </p>

        <div className="flex gap-2 flex-wrap mb-6">
          <span className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg font-semibold text-sm">Fast Delivery</span>
          <span className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg font-semibold text-sm">Transparent Pricing</span>
          <span className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg font-semibold text-sm">Local Support (Pakistan)</span>
        </div>

        <div className="flex gap-3 flex-wrap">
          <a href="#contact" className="px-4 py-2 bg-yellow-400 text-black font-bold rounded-lg">Start Project</a>
          <a href="#services" className="px-4 py-2 border border-white/10 rounded-lg">View Services</a>
        </div>
      </div>

      <div className="bg-white/5 border border-white/10 p-5 rounded-xl">
        <h3 className="text-lg font-bold mb-1">Book a 30-minute call</h3>
        <p className="text-gray-400 text-sm mb-4">Free Consultation</p>

        <form className="flex flex-col gap-3" onSubmit={(e)=>{e.preventDefault(); alert('Request sent')}}>
          <input className="bg-transparent border border-white/10 p-2 rounded-lg" placeholder="Your name" />
          <input className="bg-transparent border border-white/10 p-2 rounded-lg" placeholder="Email" />
          <input className="bg-transparent border border-white/10 p-2 rounded-lg" placeholder="Phone" />
          <button className="px-4 py-2 bg-yellow-400 text-black font-bold rounded-lg">Request Call</button>
        </form>
      </div>
    </section>
  )
}

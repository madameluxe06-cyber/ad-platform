export default function About() {
  return (
    <section id="about" className="max-w-6xl mx-auto px-5 py-20">
      <h2 className="text-3xl font-bold mb-3">About 1</h2>
      <p className="text-gray-400 max-w-3xl">
        We are a small team of designers, strategists and developers focused on helping
        companies improve their digital presence. Based in Pakistan, we combine
        international standards with local market knowledge.
      </p>
    </section>
  )
}

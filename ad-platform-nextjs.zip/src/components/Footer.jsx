export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-6 mt-10">
      <div className="max-w-6xl mx-auto px-5 text-gray-400 text-sm flex justify-between flex-wrap gap-4">
        <span>1 — Premium Solutions © 2025</span>
        <span>Lahore, Pakistan</span>
      </div>
    </footer>
  )
}

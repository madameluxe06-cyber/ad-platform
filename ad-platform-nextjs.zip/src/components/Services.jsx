export default function Services() {
  return (
    <section id="services" className="max-w-6xl mx-auto px-5 py-20">
      <h2 className="text-3xl font-bold mb-6">Our Services</h2>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white/5 border border-white/10 p-6 rounded-xl">
          <div className="text-3xl mb-3">💼</div>
          <h3 className="text-xl font-semibold mb-2">Consulting</h3>
          <p className="text-gray-400 text-sm">Business & product strategy, market research and growth planning.</p>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 rounded-xl">
          <div className="text-3xl mb-3">🌐</div>
          <h3 className="text-xl font-semibold mb-2">Web Design</h3>
          <p className="text-gray-400 text-sm">Modern responsive websites built for conversions — fast & SEO-friendly.</p>
        </div>

        <div className="bg-white/5 border border-white/10 p-6 rounded-xl">
          <div className="text-3xl mb-3">📣</div>
          <h3 className="text-xl font-semibold mb-2">Digital Marketing</h3>
          <p className="text-gray-400 text-sm">Social ads, search ads, content strategy and email marketing.</p>
        </div>
      </div>
    </section>
  )
}

export default function Contact() {
  return (
    <section id="contact" className="max-w-6xl mx-auto px-5 py-20 grid md:grid-cols-2 gap-8">
      <div className="bg-white/5 border border-white/10 p-6 rounded-xl">
        <h3 className="text-xl font-semibold mb-2">Get in touch</h3>
        <p className="text-gray-400 text-sm mb-4">Tell us about your project. We'll reply within one business day.</p>

        <form className="grid gap-3" onSubmit={(e)=>{e.preventDefault(); alert('Message sent')}}>
          <input className="bg-transparent border border-white/10 p-3 rounded-lg" placeholder="Your name" />
          <input className="bg-transparent border border-white/10 p-3 rounded-lg" placeholder="Email" />
          <input className="bg-transparent border border-white/10 p-3 rounded-lg" placeholder="Phone" />
          <textarea className="bg-transparent border border-white/10 p-3 rounded-lg" rows={5} placeholder="Message" />
          <button className="px-4 py-2 bg-yellow-400 text-black font-bold rounded-lg">Send Message</button>
        </form>
      </div>

      <div className="bg-white/5 border border-white/10 p-6 rounded-xl">
        <h3 className="text-lg font-bold mb-2">Visit / Call</h3>
        <p className="text-gray-400 text-sm">Lahore, Pakistan<br/>Phone: +92 300 0000000<br/>Email: hello@1.example</p>
      </div>
    </section>
  )
}

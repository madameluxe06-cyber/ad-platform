import './globals.css'

export const metadata = {
  title: 'ad-platform',
  description: 'Simple business site - Sheland Classifieds frontend',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
